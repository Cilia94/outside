
fallback.load({

	jQuery: ['//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js',
	'js/vendor/jquery-1.11.2.min.js'
	],

	fontAwesome: ['//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css', 
	'js/vendor/fontawesome/css/font-awesome.min.css'],

	Bootstrap: [ 'js/vendor/bootstrap.min.js'
	],

	Handlebars: [ 'js/vendor/handlebars.min.js'
	],

	mfp: ['js/vendor/magnific-popup/jquery.magnific-popup.js'
	]
	,

	'script.js': 'js/script.js'
	
}, {
	shim: {
		'script.js' :['jQuery','Handlebars','mfp', 'Bootstrap'],
		'index.php': 'script.js',
		'Bootstrap': 'jQuery',
		'Handlebars': 'jQuery',
		'mfp': 'jQuery'
	},

	 callback: function(success, failed) {
        // Inline Callback
        console.log(success,failed)
    }
});

fallback.ready(function() {
	// Execute my code here!
	console.log("fallback is ready");
});